var struct_efeito_nefasto =
[
    [ "next", "struct_efeito_nefasto.html#a903dcacddaa96b826e513136456f6bd4", null ],
    [ "posicao", "struct_efeito_nefasto.html#a70f79e1587c918c124669640f0743d0b", null ]
];