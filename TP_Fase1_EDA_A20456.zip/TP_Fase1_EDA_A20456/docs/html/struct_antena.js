var struct_antena =
[
    [ "frequencia", "struct_antena.html#a98d94cd90b6d9288fc867dbe7a6b6f41", null ],
    [ "next", "struct_antena.html#ae518c9afee14b875ac030364762e23ba", null ],
    [ "posicao", "struct_antena.html#ad54bac1408edf998ca7e1b40839091c8", null ]
];