var files_dup =
[
    [ "antenas.c", "antenas_8c.html", "antenas_8c" ],
    [ "antenas.h", "antenas_8h.html", "antenas_8h" ],
    [ "main.c", "main_8c.html", "main_8c" ],
    [ "main_sem_menu.c", "main__sem__menu_8c.html", "main__sem__menu_8c" ]
];