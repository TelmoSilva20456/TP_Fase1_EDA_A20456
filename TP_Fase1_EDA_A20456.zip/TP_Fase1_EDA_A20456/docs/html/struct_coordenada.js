var struct_coordenada =
[
    [ "coluna", "struct_coordenada.html#a412dc325f6a4ccb65eed10b8c5e6e528", null ],
    [ "linha", "struct_coordenada.html#acf95e43b1e6d62545dd2794b09c2de63", null ]
];