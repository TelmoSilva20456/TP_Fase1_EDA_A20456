var annotated_dup =
[
    [ "Antena", "struct_antena.html", "struct_antena" ],
    [ "Coordenada", "struct_coordenada.html", "struct_coordenada" ],
    [ "EfeitoNefasto", "struct_efeito_nefasto.html", "struct_efeito_nefasto" ]
];