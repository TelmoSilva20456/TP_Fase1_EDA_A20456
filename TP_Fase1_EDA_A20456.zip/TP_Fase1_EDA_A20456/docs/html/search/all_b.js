var searchData=
[
  ['salvar_5fantenas_5farquivo_0',['salvar_antenas_arquivo',['../antenas_8c.html#adfe6707f422f1baa7f72be4f731a20cc',1,'salvar_antenas_arquivo(const char *nome_arquivo, Antena *lista):&#160;antenas.c'],['../antenas_8h.html#adfe6707f422f1baa7f72be4f731a20cc',1,'salvar_antenas_arquivo(const char *nome_arquivo, Antena *lista):&#160;antenas.c']]]
];
