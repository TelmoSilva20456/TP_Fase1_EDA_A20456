var searchData=
[
  ['atualizarmatrizcomefeitos_0',['atualizarMatrizComEfeitos',['../antenas_8c.html#aac534a21da9bc8e3d2248573c43ba906',1,'atualizarMatrizComEfeitos(char **matriz, EfeitoNefasto *efeitos):&#160;antenas.c'],['../antenas_8h.html#aac534a21da9bc8e3d2248573c43ba906',1,'atualizarMatrizComEfeitos(char **matriz, EfeitoNefasto *efeitos):&#160;antenas.c']]]
];
