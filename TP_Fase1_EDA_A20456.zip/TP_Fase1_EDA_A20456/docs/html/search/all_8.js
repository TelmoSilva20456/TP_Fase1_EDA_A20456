var searchData=
[
  ['next_0',['next',['../struct_antena.html#ae518c9afee14b875ac030364762e23ba',1,'Antena::next'],['../struct_efeito_nefasto.html#a903dcacddaa96b826e513136456f6bd4',1,'EfeitoNefasto::next']]]
];
