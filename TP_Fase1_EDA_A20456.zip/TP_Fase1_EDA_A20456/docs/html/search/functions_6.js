var searchData=
[
  ['main_0',['main',['../main_8c.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main():&#160;main.c'],['../main__sem__menu_8c.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main():&#160;main_sem_menu.c']]],
  ['marcarantenasnamatriz_1',['marcarAntenasNaMatriz',['../antenas_8c.html#a336d28a2a717d933c58e37faf20acabf',1,'marcarAntenasNaMatriz(char **matriz, Antena *lista):&#160;antenas.c'],['../antenas_8h.html#a336d28a2a717d933c58e37faf20acabf',1,'marcarAntenasNaMatriz(char **matriz, Antena *lista):&#160;antenas.c']]]
];
