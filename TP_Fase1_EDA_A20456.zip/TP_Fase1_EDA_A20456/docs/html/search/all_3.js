var searchData=
[
  ['frequencia_0',['frequencia',['../struct_antena.html#a98d94cd90b6d9288fc867dbe7a6b6f41',1,'Antena']]]
];
