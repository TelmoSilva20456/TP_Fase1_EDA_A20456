var searchData=
[
  ['linha_0',['linha',['../struct_coordenada.html#acf95e43b1e6d62545dd2794b09c2de63',1,'Coordenada']]]
];
