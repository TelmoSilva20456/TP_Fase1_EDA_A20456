var searchData=
[
  ['coordenada_0',['Coordenada',['../struct_coordenada.html',1,'']]]
];
