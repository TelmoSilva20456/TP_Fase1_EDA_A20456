var searchData=
[
  ['libertarlistaantenas_0',['libertarListaAntenas',['../antenas_8c.html#a1b17ec16918e68267b1ac12f215d5cc6',1,'libertarListaAntenas(Antena *lista):&#160;antenas.c'],['../antenas_8h.html#a1b17ec16918e68267b1ac12f215d5cc6',1,'libertarListaAntenas(Antena *lista):&#160;antenas.c']]],
  ['libertarlistaefeitos_1',['libertarListaEfeitos',['../antenas_8c.html#acdb8cb70a3bcb6e244835103450ecf38',1,'libertarListaEfeitos(EfeitoNefasto *lista):&#160;antenas.c'],['../antenas_8h.html#acdb8cb70a3bcb6e244835103450ecf38',1,'libertarListaEfeitos(EfeitoNefasto *lista):&#160;antenas.c']]],
  ['libertarmatriz_2',['libertarMatriz',['../antenas_8c.html#a77484e72dda946869ea899022c71c498',1,'libertarMatriz(char **matriz, int linhas):&#160;antenas.c'],['../antenas_8h.html#a77484e72dda946869ea899022c71c498',1,'libertarMatriz(char **matriz, int linhas):&#160;antenas.c']]],
  ['limpar_5ftela_3',['limpar_tela',['../main_8c.html#a4d086ec4c843d3d7c68afbd5dd5c9eee',1,'main.c']]],
  ['linha_4',['linha',['../struct_coordenada.html#acf95e43b1e6d62545dd2794b09c2de63',1,'Coordenada']]],
  ['listarantenas_5',['listarAntenas',['../antenas_8c.html#ad8e25ea7e05f77d363c12d6f63e7ebde',1,'listarAntenas(Antena *lista):&#160;antenas.c'],['../antenas_8h.html#ad8e25ea7e05f77d363c12d6f63e7ebde',1,'listarAntenas(Antena *lista):&#160;antenas.c']]],
  ['listarefeitos_6',['listarEfeitos',['../antenas_8c.html#ad6462c4a35b2619d16154471b7338a6e',1,'listarEfeitos(EfeitoNefasto *lista):&#160;antenas.c'],['../antenas_8h.html#ad6462c4a35b2619d16154471b7338a6e',1,'listarEfeitos(EfeitoNefasto *lista):&#160;antenas.c']]]
];
