var searchData=
[
  ['verificar_5finterferencia_0',['verificar_interferencia',['../antenas_8c.html#a418da31eb6f76aebaacdb080d074f536',1,'verificar_interferencia(Antena *antena1, Antena *antena2, Coordenada *ponto):&#160;antenas.c'],['../antenas_8h.html#a418da31eb6f76aebaacdb080d074f536',1,'verificar_interferencia(Antena *antena1, Antena *antena2, Coordenada *ponto):&#160;antenas.c']]]
];
