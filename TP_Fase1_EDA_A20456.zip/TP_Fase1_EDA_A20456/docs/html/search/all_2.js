var searchData=
[
  ['efeitonefasto_0',['EfeitoNefasto',['../struct_efeito_nefasto.html',1,'EfeitoNefasto'],['../antenas_8h.html#a6167db7f1ec0c34503d24b77b3613bfa',1,'EfeitoNefasto:&#160;antenas.h']]],
  ['esta_5falinhado_1',['esta_alinhado',['../antenas_8c.html#a9b0cad755e478dbbfb3567563978fdb8',1,'antenas.c']]],
  ['exibir_5fmatriz_5fefeito_5fnefasto_2',['exibir_matriz_efeito_nefasto',['../antenas_8c.html#aa1747f6c5ff3f00d31cdd302b709bef5',1,'exibir_matriz_efeito_nefasto(char **matriz, int linhas, int colunas):&#160;antenas.c'],['../antenas_8h.html#aa1747f6c5ff3f00d31cdd302b709bef5',1,'exibir_matriz_efeito_nefasto(char **matriz, int linhas, int colunas):&#160;antenas.c']]],
  ['exibir_5fmatriz_5fposicionamento_3',['exibir_matriz_posicionamento',['../antenas_8c.html#a28f61e9b5aec6223d7d48169b0ae6d09',1,'exibir_matriz_posicionamento(char **matriz, int linhas, int colunas):&#160;antenas.c'],['../antenas_8h.html#a28f61e9b5aec6223d7d48169b0ae6d09',1,'exibir_matriz_posicionamento(char **matriz, int linhas, int colunas):&#160;antenas.c']]],
  ['exibir_5fmenu_4',['exibir_menu',['../main_8c.html#a2f96e05fbc015d7fc462a99c1b8457df',1,'main.c']]]
];
