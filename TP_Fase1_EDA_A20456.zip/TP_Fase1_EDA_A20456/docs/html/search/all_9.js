var searchData=
[
  ['posicao_0',['posicao',['../struct_antena.html#ad54bac1408edf998ca7e1b40839091c8',1,'Antena::posicao'],['../struct_efeito_nefasto.html#a70f79e1587c918c124669640f0743d0b',1,'EfeitoNefasto::posicao']]]
];
