var searchData=
[
  ['inicializar_5flista_0',['inicializar_lista',['../antenas_8c.html#ae3587244c6931bcb17077440ba197069',1,'inicializar_lista():&#160;antenas.c'],['../antenas_8h.html#ae3587244c6931bcb17077440ba197069',1,'inicializar_lista():&#160;antenas.c']]],
  ['inicializar_5fmatriz_5fefeito_5fnefasto_1',['inicializar_matriz_efeito_nefasto',['../antenas_8c.html#abd6f45ec1d923b0ff92d11ef1233d30c',1,'inicializar_matriz_efeito_nefasto(int linhas, int colunas):&#160;antenas.c'],['../antenas_8h.html#abd6f45ec1d923b0ff92d11ef1233d30c',1,'inicializar_matriz_efeito_nefasto(int linhas, int colunas):&#160;antenas.c']]],
  ['inicializarmatriz_2',['inicializarMatriz',['../antenas_8c.html#a070093abbf87ed36808fecc77e75d8f4',1,'inicializarMatriz(int linhas, int colunas):&#160;antenas.c'],['../antenas_8h.html#a070093abbf87ed36808fecc77e75d8f4',1,'inicializarMatriz(int linhas, int colunas):&#160;antenas.c']]],
  ['inserir_5fantenas_5finiciais_3',['inserir_antenas_iniciais',['../antenas_8c.html#a40c77060abab61d0a818dafbcd1002b9',1,'inserir_antenas_iniciais(Antena **lista):&#160;antenas.c'],['../antenas_8h.html#a40c77060abab61d0a818dafbcd1002b9',1,'inserir_antenas_iniciais(Antena **lista):&#160;antenas.c']]],
  ['inserirantena_4',['inserirAntena',['../antenas_8c.html#a8bb5487b89754ea223b5aadadd9ecd59',1,'inserirAntena(Antena *lista, char frequencia, int linha, int coluna):&#160;antenas.c'],['../antenas_8h.html#a8bb5487b89754ea223b5aadadd9ecd59',1,'inserirAntena(Antena *lista, char frequencia, int linha, int coluna):&#160;antenas.c']]]
];
