var searchData=
[
  ['calcular_5fdistancia_0',['calcular_distancia',['../antenas_8c.html#a5a63c51c1ed0a8acb8df4677218c41eb',1,'antenas.c']]],
  ['calcularefeitonefasto_1',['calcularEfeitoNefasto',['../antenas_8c.html#a63e01f1658a75c616851d6f700bb95d2',1,'calcularEfeitoNefasto(Antena *lista, int linhas, int colunas):&#160;antenas.c'],['../antenas_8h.html#a63e01f1658a75c616851d6f700bb95d2',1,'calcularEfeitoNefasto(Antena *lista, int linhas, int colunas):&#160;antenas.c']]],
  ['carregarantenasdeficheiro_2',['carregarAntenasDeFicheiro',['../antenas_8c.html#afaa494dfe21284cc4fcf865fcc960391',1,'carregarAntenasDeFicheiro(const char *nome_arquivo, int *linhas, int *colunas):&#160;antenas.c'],['../antenas_8h.html#afaa494dfe21284cc4fcf865fcc960391',1,'carregarAntenasDeFicheiro(const char *nome_arquivo, int *linhas, int *colunas):&#160;antenas.c']]]
];
