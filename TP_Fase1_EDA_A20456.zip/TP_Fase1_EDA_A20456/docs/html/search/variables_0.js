var searchData=
[
  ['coluna_0',['coluna',['../struct_coordenada.html#a412dc325f6a4ccb65eed10b8c5e6e528',1,'Coordenada']]]
];
