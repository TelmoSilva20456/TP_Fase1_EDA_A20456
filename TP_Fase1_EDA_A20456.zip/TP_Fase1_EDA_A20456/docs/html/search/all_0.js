var searchData=
[
  ['antena_0',['Antena',['../struct_antena.html',1,'Antena'],['../antenas_8h.html#a843ab8b81393e8ebb3eb6b76e349acc2',1,'Antena:&#160;antenas.h']]],
  ['antenas_2ec_1',['antenas.c',['../antenas_8c.html',1,'']]],
  ['antenas_2eh_2',['antenas.h',['../antenas_8h.html',1,'']]],
  ['atualizarmatrizcomefeitos_3',['atualizarMatrizComEfeitos',['../antenas_8c.html#aac534a21da9bc8e3d2248573c43ba906',1,'atualizarMatrizComEfeitos(char **matriz, EfeitoNefasto *efeitos):&#160;antenas.c'],['../antenas_8h.html#aac534a21da9bc8e3d2248573c43ba906',1,'atualizarMatrizComEfeitos(char **matriz, EfeitoNefasto *efeitos):&#160;antenas.c']]]
];
