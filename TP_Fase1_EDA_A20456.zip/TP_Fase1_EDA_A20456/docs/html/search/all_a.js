var searchData=
[
  ['removerantena_0',['removerAntena',['../antenas_8c.html#ae1618377754cbd6153e90c198fc1630c',1,'removerAntena(Antena *lista, int linha, int coluna):&#160;antenas.c'],['../antenas_8h.html#ae1618377754cbd6153e90c198fc1630c',1,'removerAntena(Antena *lista, int linha, int coluna):&#160;antenas.c']]]
];
